class LivecountseditInterface {
    constructor () {
        this.suffixValues = {
            'k': 1e3,
            'm': 1e6,
            'b': 1e9,
            't': 1e12,
            'q': 1e15,
        },
        this.openTab = function (e,f) {
            var a,b,c;
            b = document.getElementsByClassName('tab-content');
            for (a = 0; a < b.length; a++) {
                b[a].style.display = 'none';
            }
            c = document.getElementsByClassName('tab-link');
            for (a = 0; a < c.length; a++) {
                c[a].className = c[a].className.replace(' active', '');
            }
            document.getElementById(f).style.display = 'block';
            e.currentTarget.className += ' active'
        },
        this.rickroll = function () {
            window.location.replace('https://youtu.be/dQw4w9WgXcQ')
        },
        this.setBanner = function () {
            if (!document.getElementById("options.counter.banner.file").files.length) {
                if (!document.getElementById("options.counter.banner.url").value) return;
                else document.querySelector(".banner").src = document.getElementById("options.counter.banner.url").value
            } else {
                document.querySelector(".banner").src = URL.createObjectURL(document.getElementById("options.counter.banner.file").files[0])
            }
        },
        this.setAvatar = function () {
            if (!document.getElementById("options.counter.avatar.file").files.length) {
                if (!document.getElementById("options.counter.avatar.url").value) return;
                else document.querySelector(".avatar").src = document.getElementById("options.counter.avatar.url").value
            } else {
                document.querySelector(".avatar").src = URL.createObjectURL(document.getElementById("options.counter.avatar.file").files[0])
            }
        }
    }
}
const Interface = new LivecountseditInterface()
window.onload = function () {
    if (document.getElementById('tabs.0')) document.getElementById('tabs.0').click();
}
document.getElementById("options.counter.banner.file").addEventListener('input', Interface.setBanner)
document.getElementById("options.counter.avatar.file").addEventListener('input', Interface.setAvatar)
